# RK-18 — Web Restriction Unlocker

**RK-18** is a Google Chrome extension designed to bypass restrictive web page behaviors. It restores right-click context menus, enables text selection and copy-pasting, and neutralizes blocking event handlers.

---

## 🚀 Features

- **Context Menu Unblock:** Re-enables disabled right-click menus on any webpage.
- **Text Selection & Copy:** Overrides `user-select: none` and unblocks copy/cut actions.
- **Keyboard Shortcut Unlock:** Neutralizes scripts attempting to block inspect shortcuts and common copy keys.
- **Email OTP Activation:** Secure 6-digit one-time password sent directly to your student email.
- **One-Click Toggle:** Easily enable or pause protection from the extension toolbar popup.
- **Tab Reload Helper:** Instant tab refresh button to apply unlocking rules immediately.

---

## 📥 How to Install (For Students)

1. **Download & Extract:**
   - Download `RK-18.zip`.
   - Right-click the `.zip` file and select **Extract All...** to extract it into a folder.

2. **Open Extensions in Chrome:**
   - Open Google Chrome.
   - In the address bar, type `chrome://extensions/` and press **Enter**.

3. **Enable Developer Mode:**
   - In the top-right corner of the Extensions page, switch **Developer mode** to **ON**.

4. **Load the Extension:**
   - Click the **Load unpacked** button in the top-left corner.
   - Select the extracted `rk-18` folder.

5. **Pin RK-18:**
   - Click the puzzle piece icon (Extensions) in the Chrome toolbar.
   - Click the pin icon next to **RK-18** so it stays visible on your toolbar.

---

## 🔑 Activation Guide

1. Click on the **RK-18** icon in your Chrome toolbar.
2. Enter your email address and click **Send Code**.
3. Check your email inbox (and Spam/Junk folder) for a 6-digit verification code.
4. Enter the 6-digit code in the popup and click **Verify & Unlock**.
5. The extension status badge will switch from **LOCK** to **ON**. You're all set!

---

## ⚙️ How to Use

- **Toolbar Badge:**
  - `ON` (Green): Protection is active and running on all pages.
  - `OFF` (Red): Protection is temporarily paused.
  - `LOCK` (Amber): Awaiting student email OTP verification.
- **Popup Controls:**
  - Toggle the switch to turn unlocking on or off at any time.
  - Click **Reload Current Tab** to refresh and unblock an already-open page.

---

## 🛠️ Project Structure

```text
rk-18/
├── manifest.json       # Chrome Manifest V3 configuration
├── background.js      # Service worker managing state and dynamic injection
├── unlock.js          # Core injection script neutralizing blocking listeners
├── selection.css      # Stylesheet enforcing user-select: text !important
├── popup.html         # User interface with OTP authentication & toggle
├── popup.js           # Client logic connecting to OTP backend
├── icons/             # Multi-resolution extension icons (16, 32, 48, 128px)
└── README.md          # User & installation guide
```

---

## ❓ FAQ & Troubleshooting

- **Didn't receive the OTP code?**
  - Verify that your email address was typed correctly.
  - Check your **Spam** or **Junk** folder.
  - Click "Change email / Resend" in the popup to request a new code.
- **Website still blocking right-click?**
  - Click the RK-18 extension icon and click **Reload Current Tab**.
  - Ensure the status badge displays **ON**.
