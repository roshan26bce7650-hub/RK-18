// popup.js - Email OTP Authentication & Controller for RK-18
const API_URL = 'https://script.google.com/macros/s/AKfycbxLAj4haltvsFWywRWKMHbNLiOMl4Guj29_D9IES3V5sofhA4FfQl8kLdbJgNRm5qkg/exec';

// Screen Elements
const screenEmail = document.getElementById('screenEmail');
const screenOtp = document.getElementById('screenOtp');
const screenDashboard = document.getElementById('screenDashboard');
const dashboardFooter = document.getElementById('dashboardFooter');
const statusPill = document.getElementById('statusPill');

// Form Elements
const emailInput = document.getElementById('emailInput');
const sendOtpBtn = document.getElementById('sendOtpBtn');
const emailError = document.getElementById('emailError');

const otpInput = document.getElementById('otpInput');
const otpDesc = document.getElementById('otpDesc');
const verifyOtpBtn = document.getElementById('verifyOtpBtn');
const otpError = document.getElementById('otpError');
const backEmailBtn = document.getElementById('backEmailBtn');

// Dashboard Controls
const powerToggle = document.getElementById('powerToggle');
const toggleSub = document.getElementById('toggleSub');
const featureList = document.querySelector('.feature-list');
const reloadBtn = document.getElementById('reloadBtn');
const userEmailFooter = document.getElementById('userEmailFooter');

let currentEmail = '';

function showScreen(screen) {
  screenEmail.classList.remove('active-screen');
  screenOtp.classList.remove('active-screen');
  screenDashboard.classList.remove('active-screen');
  dashboardFooter.style.display = 'none';

  if (screen === 'email') {
    screenEmail.classList.add('active-screen');
    statusPill.textContent = 'LOCKED';
    statusPill.className = 'status-pill locked';
  } else if (screen === 'otp') {
    screenOtp.classList.add('active-screen');
    statusPill.textContent = 'VERIFY';
    statusPill.className = 'status-pill locked';
  } else if (screen === 'dashboard') {
    screenDashboard.classList.add('active-screen');
    dashboardFooter.style.display = 'block';
  }
}

function updateDashboardUI(enabled) {
  powerToggle.checked = enabled;
  if (enabled) {
    statusPill.textContent = 'ACTIVE';
    statusPill.className = 'status-pill active';
    toggleSub.textContent = 'All features running';
    featureList.classList.remove('disabled');
  } else {
    statusPill.textContent = 'DISABLED';
    statusPill.className = 'status-pill disabled';
    toggleSub.textContent = 'Protection paused';
    featureList.classList.add('disabled');
  }
}

// 1. Initialize State
document.addEventListener('DOMContentLoaded', async () => {
  const { rk18_unlocked, rk18_enabled, rk18_user_email } = await chrome.storage.local.get({
    rk18_unlocked: false,
    rk18_enabled: true,
    rk18_user_email: ''
  });

  if (rk18_unlocked) {
    showScreen('dashboard');
    updateDashboardUI(rk18_enabled);
    if (rk18_user_email) {
      userEmailFooter.textContent = 'Registered to ' + rk18_user_email;
    }
  } else {
    showScreen('email');
  }
});

// 2. Send OTP
sendOtpBtn.addEventListener('click', async () => {
  const email = emailInput.value.trim().toLowerCase();
  emailError.style.display = 'none';

  if (!email || !email.includes('@') || !email.includes('.')) {
    emailError.textContent = 'Please enter a valid email address.';
    emailError.style.display = 'block';
    return;
  }

  sendOtpBtn.disabled = true;
  sendOtpBtn.textContent = 'Sending code...';

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'send_otp', email: email })
    });

    const data = await res.json();
    if (data.success) {
      currentEmail = email;
      otpDesc.textContent = `Code sent to ${email}`;
      otpInput.value = '';
      showScreen('otp');
    } else {
      emailError.textContent = data.error || 'Failed to send OTP. Try again.';
      emailError.style.display = 'block';
    }
  } catch (err) {
    emailError.textContent = 'Connection error. Please try again.';
    emailError.style.display = 'block';
  } finally {
    sendOtpBtn.disabled = false;
    sendOtpBtn.textContent = 'Send Code';
  }
});

// 3. Verify OTP
verifyOtpBtn.addEventListener('click', async () => {
  const otp = otpInput.value.trim();
  otpError.style.display = 'none';

  if (!otp || otp.length < 6) {
    otpError.textContent = 'Please enter the 6-digit code.';
    otpError.style.display = 'block';
    return;
  }

  verifyOtpBtn.disabled = true;
  verifyOtpBtn.textContent = 'Verifying...';

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'verify_otp', email: currentEmail, otp: otp })
    });

    const data = await res.json();
    if (data.success && data.verified) {
      chrome.runtime.sendMessage({ action: 'SET_UNLOCKED', email: currentEmail }, () => {
        showScreen('dashboard');
        updateDashboardUI(true);
        userEmailFooter.textContent = 'Registered to ' + currentEmail;
      });
    } else {
      otpError.textContent = data.error || 'Incorrect or expired code.';
      otpError.style.display = 'block';
    }
  } catch (err) {
    otpError.textContent = 'Verification error. Check your connection.';
    otpError.style.display = 'block';
  } finally {
    verifyOtpBtn.disabled = false;
    verifyOtpBtn.textContent = 'Verify & Unlock';
  }
});

// Back to Email screen
backEmailBtn.addEventListener('click', () => {
  showScreen('email');
});

// 4. Toggle Switch
powerToggle.addEventListener('change', () => {
  const enabled = powerToggle.checked;
  chrome.runtime.sendMessage({ action: 'SET_ENABLED', enabled }, response => {
    if (response && response.success) {
      updateDashboardUI(response.enabled);
    }
  });
});

// 5. Reload Current Tab
reloadBtn.addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      chrome.tabs.reload(tab.id);
    }
  } catch (err) {
    console.error('Error reloading tab:', err);
  }
});
