// background.js - Service Worker for RK-18
const SCRIPT_ID = 'rk18-core';
const CSS_ID = 'rk18-css';

let queue = Promise.resolve();

function updateState(enabled, unlocked) {
  // Ensure calls execute sequentially to prevent race conditions
  queue = queue.then(async () => {
    // 1. Check if extension is unlocked via Email OTP
    if (!unlocked) {
      try {
        await chrome.action.setBadgeText({ text: 'LOCK' });
        await chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' }); // Amber warning
      } catch (_) {}
      enabled = false;
    } else {
      // 2. Update toolbar badge
      try {
        if (enabled) {
          await chrome.action.setBadgeText({ text: 'ON' });
          await chrome.action.setBadgeBackgroundColor({ color: '#16a34a' });
        } else {
          await chrome.action.setBadgeText({ text: 'OFF' });
          await chrome.action.setBadgeBackgroundColor({ color: '#dc2626' });
        }
      } catch (_) {}
    }

    // 3. Check current registration status
    let existingIds = [];
    try {
      const existing = await chrome.scripting.getRegisteredContentScripts();
      existingIds = existing.map(s => s.id);
    } catch (err) {
      console.warn('Could not query registered scripts:', err);
    }

    if (enabled && unlocked) {
      if (existingIds.includes(SCRIPT_ID)) {
        return;
      }

      try {
        await chrome.scripting.registerContentScripts([
          {
            id: SCRIPT_ID,
            matches: ['<all_urls>'],
            js: ['unlock.js'],
            runAt: 'document_start',
            allFrames: true,
            matchOriginAsFallback: true,
            world: 'MAIN'
          },
          {
            id: CSS_ID,
            matches: ['<all_urls>'],
            css: ['selection.css'],
            runAt: 'document_start',
            allFrames: true,
            matchOriginAsFallback: true
          }
        ]);
      } catch (err) {
        if (!err.message?.includes('Duplicate script ID')) {
          console.error('Script registration error:', err);
        }
      }
    } else {
      // If disabled or locked, remove scripts if they exist
      const toUnregister = [SCRIPT_ID, CSS_ID].filter(id => existingIds.includes(id));
      if (toUnregister.length > 0) {
        try {
          await chrome.scripting.unregisterContentScripts({ ids: toUnregister });
        } catch (err) {
          console.warn('Script unregister error:', err);
        }
      }
    }
  }).catch(err => {
    console.error('State update queue error:', err);
  });

  return queue;
}

async function syncState() {
  const data = await chrome.storage.local.get({
    rk18_enabled: true,
    rk18_unlocked: false
  });
  await updateState(data.rk18_enabled, data.rk18_unlocked);
}

// Initialize on install or extension reload
chrome.runtime.onInstalled.addListener(syncState);

// Initialize on browser startup
chrome.runtime.onStartup.addListener(syncState);

// Listen for toggle & unlock requests from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'SET_ENABLED') {
    chrome.storage.local.get({ rk18_unlocked: false }).then(({ rk18_unlocked }) => {
      if (!rk18_unlocked) {
        sendResponse({ success: false, reason: 'LOCKED' });
        return;
      }
      chrome.storage.local.set({ rk18_enabled: message.enabled }).then(() => {
        updateState(message.enabled, true).then(() => {
          sendResponse({ success: true, enabled: message.enabled });
        });
      });
    });
    return true; // Keep channel open for async response
  }

  if (message.action === 'SET_UNLOCKED') {
    chrome.storage.local.set({
      rk18_unlocked: true,
      rk18_user_email: message.email,
      rk18_enabled: true
    }).then(() => {
      updateState(true, true).then(() => {
        sendResponse({ success: true });
      });
    });
    return true;
  }
});
