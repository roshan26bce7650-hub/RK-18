// unlock.js - Injected into MAIN world at document_start
(function () {
  'use strict';

  const PROTECTED_EVENTS = new Set([
    'contextmenu',
    'selectstart',
    'copy',
    'cut',
    'paste',
    'dragstart',
    'mousedown',
    'mouseup'
  ]);

  // 1. Intercept and neutralize EventTarget.prototype.addEventListener
  const originalAddEventListener = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function (type, listener, options) {
    if (typeof type === 'string' && PROTECTED_EVENTS.has(type.toLowerCase())) {
      const safeListener = function (event) {
        if (typeof listener === 'function') {
          try {
            return listener.apply(this, arguments);
          } catch (_) {}
        }
      };
      return originalAddEventListener.call(this, type, safeListener, options);
    }
    return originalAddEventListener.call(this, type, listener, options);
  };

  // 2. Prevent overriding inline handlers (e.g. document.oncontextmenu = () => false)
  PROTECTED_EVENTS.forEach(eventName => {
    const propName = 'on' + eventName;
    try {
      Object.defineProperty(document, propName, { get: () => null, set: () => true, configurable: true });
      Object.defineProperty(window, propName, { get: () => null, set: () => true, configurable: true });
    } catch (_) {}
  });

  // 3. Document-level event capture overrides to allow user actions
  ['contextmenu', 'selectstart', 'copy'].forEach(eventType => {
    window.addEventListener(eventType, event => { event.stopPropagation(); }, true);
  });

  // 4. Clean inline attributes on DOM load
  const cleanAttributes = () => {
    const elements = document.querySelectorAll('*');
    for (let i = 0; i < elements.length; i++) {
      const el = elements[i];
      if (el.hasAttribute('oncontextmenu')) el.removeAttribute('oncontextmenu');
      if (el.hasAttribute('onselectstart')) el.removeAttribute('onselectstart');
      if (el.hasAttribute('ondragstart')) el.removeAttribute('ondragstart');
      if (el.hasAttribute('oncopy')) el.removeAttribute('oncopy');
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', cleanAttributes);
  } else {
    cleanAttributes();
  }
})();